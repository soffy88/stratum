# @helios/blocks

> **跨垂直领域 Block-level UI 内核**,服务 Wiki 项目群(金融 / 知识 / 运维 / 视频 / A股)。
> 不只是组件库,是把可观测性、可追溯性、自托管哲学、跨项目命名差异化嵌入到 UI 抽象的工程基础设施。

**版本**: v1.2.9 · **状态**: ✅ 0 TS / 0 Lint / 466/466 测试通过 (100%)

---

## 5 分钟 Quick Start

### 1. 安装

```bash
pnpm add @helios/blocks
```

`@helios/blocks` 是 **thin dependency** — 它不打包 TanStack Query / Zustand / zod,你在应用层自装。

```bash
pnpm add @tanstack/react-query zustand react-hook-form zod
```

### 2. 包裹根 Provider

```tsx
// app/layout.tsx
import { ThemeProvider, ObservabilityProvider } from '@helios/blocks';
import '@helios/blocks/styles.css';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <ThemeProvider defaultTheme="terminal-dark">
          <ObservabilityProvider
            traceIdPrefix="trc_"
            channelPrefix="myapp"
          >
            {children}
          </ObservabilityProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
```

### 3. 使用 Block

```tsx
import { OKPICard, OStatusBadge, OPositionPnLCard } from '@helios/blocks';

export default function Dashboard() {
  return (
    <div className="grid grid-cols-3 gap-4 p-6">
      <OKPICard
        label="账户余额"
        value={128542.50}
        change={+2.3}
        format="usd"
      />
      <OStatusBadge status="active" label="正常运行" pulse />
      <OPositionPnLCard
        data={{ symbol: 'BTC/USDT', pnl: 1245.30, pnlPct: 1.85 }}
      />
    </div>
  );
}
```

### 4. 切换主题

```tsx
import { useTheme } from '@helios/blocks';

const { theme, setTheme } = useTheme();
// 'terminal-dark' | 'terminal-light' | 'cyberpunk' | 'professional'
// | 'academic' | 'glass' | 'zen'
```

---

## 核心理念

| 哲学 | 含义 | 例子 |
|------|------|------|
| **可追溯性 = 一等公民** | 任何 AI/自动化输出必须能反向追溯到 source | OAgentTraceViewer / citations 字段 |
| **多阶段流水线可视化** | 长任务必须暴露 stage 进度 | OBatchJobProgress(v1.3 路线图) |
| **AI 给建议,人决策** | AI 输出永远是候选,不是最终决定 | OActionApproval / dry-run 模式 |
| **数据所有权 + 自托管** | 禁 SaaS APM,允许自带 LLM key | ObservabilityProvider(只接 OTel) |

详见 [`docs/HELIOS_SPEC_v3.0.md`](./docs/HELIOS_SPEC_v3.0.md) §2。

---

## 技术栈(LOCKED per FRONTEND_STACK v1.0)

| 层 | 技术 |
|----|------|
| Runtime | Node 22 · pnpm 9 |
| 框架 | React 19.2 · Next.js 15 App Router · TypeScript 5.6+ strict |
| 样式 | Tailwind CSS 4 |
| 测试 | Vitest + RTL + Playwright |
| 应用层(各项目自装)| TanStack Query v5 · Zustand · react-hook-form + zod |

**禁用**: Redux / MobX / Recoil / Jotai / styled-components / Emotion / moment / lodash / axios / MUI / Antd。

---

## 当前状态(2026-05-22)

| 维度 | 评级 |
|------|------|
| Block 总数 | **68 Blocks + 13 Frames + 12 Providers + 8 主题** |
| TypeScript | ✅ 0 errors (strict + noUncheckedIndexedAccess) |
| ESLint | ✅ 0 errors / 0 warnings |
| 测试 | ✅ 466/466 (100%) |
| a11y 自动验证 | ✅ 19 ⭐⭐⭐ Block 通过 axe-core 验证 |
| 治理章程 | ✅ SPEC v3.0(5 协作准则)+ FRONTEND_STACK v1.0 + ADR 体系 |
| 跨项目契约 | ✅ BatchJob v0.1-draft + Stratum 5 Lock |
| 生产验证 | ⏳ 0 部署(致命短板,见 MATURITY_ROADMAP §9) |

**接入路径**:
- Stratum: ⏳ API 撰写中(2 周交付,2026-06 初接入)
- Aegis: ⏳ M2 启动(2026-07 中,经理人 R2 拍板)
- hevi: ⏳ Phase 5 (2026-Q3)
- **接入入口(统一)**: [`docs/INTEGRATION_GUIDE.md`](./docs/INTEGRATION_GUIDE.md)(含 3 条路径 / 数据契约 / 主动提需求)

完整成熟度评估见 [`docs/MATURITY_ROADMAP.md`](./docs/MATURITY_ROADMAP.md)。

---

## 文档导航

| 我想... | 看哪份文档 |
|---------|-----------|
| **第一次接触,5 分钟入门** | 本 README |
| **了解所有文档怎么分类** | [`docs/INDEX.md`](./docs/INDEX.md) ← 推荐第二个看 |
| **理解跨项目治理章程** | [`docs/HELIOS_SPEC_v3.0.md`](./docs/HELIOS_SPEC_v3.0.md) |
| **了解技术栈选型理由** | [`docs/HELIOS_FRONTEND_STACK_v1.0.md`](./docs/HELIOS_FRONTEND_STACK_v1.0.md) |
| **启动一个新项目** | SPEC v3.0 §9 新项目 Checklist |
| **看每个维度怎么升 S 级** | [`docs/MATURITY_ROADMAP.md`](./docs/MATURITY_ROADMAP.md) |
| **接入 Stratum 知识库后端** | [`docs/HELIOS_KB_SPEC_v1.0-draft.md`](./docs/HELIOS_KB_SPEC_v1.0-draft.md) + `src/types/stratum.ts` |
| **了解 snake_case 决策** | [`docs/ADR_STRATUM_SNAKE_CASE.md`](./docs/ADR_STRATUM_SNAKE_CASE.md) |
| **了解可观测性接入** | [`docs/OBSERVABILITY_GUIDE.md`](./docs/OBSERVABILITY_GUIDE.md) |
| **了解一次实证清理的元教训** | [`docs/EMPIRICAL_REPORT_2026-05-21.md`](./docs/EMPIRICAL_REPORT_2026-05-21.md) + [`docs/TECH_DEBT_CLEANUP_REPORT.md`](./docs/TECH_DEBT_CLEANUP_REPORT.md) |
| **从 v1.1 升级到 v1.2** | [`docs/MIGRATION_v1.1_TO_v1.2.md`](./docs/MIGRATION_v1.1_TO_v1.2.md) |

---

## 质量门槛(强制)

任何 PR 合并前必须本地跑过:

```bash
pnpm typecheck   # 0 errors(strict + noUncheckedIndexedAccess)
pnpm lint        # 0 errors 0 warnings
pnpm test        # 通过率 100%
```

**双重门槛**:
- CI workflow(`.github/workflows/ci.yml`)
- pre-commit hook(`.githooks/pre-commit`)

启用 hook:
```bash
git config core.hooksPath .githooks
```

---

## 项目群定位

`@helios/blocks` 是 Wiki **7 项目生态**的共享 UI 内核(Layer 3):

```
┌────────────────────────────────────────────────────────────┐
│  Layer 6: 应用层(各项目 Next.js app)        ← 项目独立      │
│  Layer 5: 项目专属 Block                    ← 各项目 src/*  │
│  Layer 4: 应用层共享(TanStack/Zustand)      ← 各项目 npm   │
│  Layer 3: @helios/blocks                    ← 本 repo       │
│  Layer 2: 平台 SDK(Stratum / Aegis 后端)    ← 后端项目     │
│  Layer 1: 基础设施(DB / WebSocket / LLM)    ← 自托管       │
└────────────────────────────────────────────────────────────┘
```

| 项目 | 状态 | 命名 |
|------|------|------|
| **Helios** 加密终端 | ✅ v1.1 | camelCase |
| **Stratum** 知识库 | ⏳ API 中(2周)| **snake_case** |
| **Aegis** 智能运维 | ⏳ swagger 中 | TBD |
| **hevi** 视频自动化 | ⏳ Phase 5 (Q3) | TBD |
| Tide / Helixa / Selene | 🟢 未启动 | TBD |

---

## 贡献

目前为 Wiki 项目群 internal 开发。外部贡献渠道未开放(见 MATURITY_ROADMAP §10 社区维度)。

---

## License

MIT

---

— Helios 前端架构组 · 2026-05-21
